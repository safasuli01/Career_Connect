import React from 'react';
import AppRoutes from './routes/AppRoute';

function App() {
  return (
    <div>
      <AppRoutes />
    </div>
  );
}

export default App;
